package stepDefinitions;

import Mobiles.Flipkart.BaseDriver;
import io.cucumber.java.After;

public class Hooks extends BaseDriver {
	
	@After("@FlipkartTest")
	public void afterValidation() {
		
		driver.close();
	}

}
