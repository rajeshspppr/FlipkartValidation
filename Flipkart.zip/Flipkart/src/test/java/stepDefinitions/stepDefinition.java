package stepDefinitions;

import org.junit.runner.RunWith;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import Mobiles.Flipkart.BaseDriver;
import Mobiles.Flipkart.flipkartXpath;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;
import junit.framework.Assert;


@RunWith(Cucumber.class)
public class stepDefinition{
	public WebDriver driver;
	flipkartXpath flip = new flipkartXpath();

	
		
	 @Given("^Launch flipkart url$")
	    public void launch_flipkart_url() throws Throwable {
		 
		 driver = BaseDriver.getDriver();
		 
		 Thread.sleep(3000);
		 if(driver.findElement(flip.Login_Close).isDisplayed()) {
			 driver.findElement(flip.Login_Close).click();
			 Thread.sleep(2000);
		 }
	    
	    }

	    @When("^user search for mobiles$")
	    public void user_search_for_mobiles() throws Throwable {
	    	
	    	driver.findElement(flip.Fld_Search).sendKeys("mobile");
	    	Thread.sleep(2000);
	    	Actions act = new Actions(driver);
	        act.sendKeys(Keys.ENTER).build().perform();
	        Thread.sleep(2000);
	    }

	    @Then("^Validate the result contains Gionee mobile with capacity 2GB$")
	    public void validate_the_result_contains_gionee_mobile_with_capacity_2gb() throws Throwable {
	       Assert.assertTrue(driver.findElement(flip.Lnk_FirstMobile).isDisplayed());
	       Assert.assertTrue(driver.findElement(flip.Txt_First2GB).isDisplayed());
	       Thread.sleep(2000);
	    }

	    @And("^Select Brand Gionee mobile in left pane$")
	    public void select_brand_gionee_mobile_in_left_pane() throws Throwable {
	        driver.findElement(flip.Lnk_More).click();
	        Thread.sleep(2000);
	        driver.findElement(flip.Fld_SearchBrand).sendKeys("Gionee");
	        Thread.sleep(2000);
	        driver.findElement(flip.Chk_Gionee).click();
	        Thread.sleep(2000);
	        driver.findElement(flip.Btn_AplyFilters).click();
	        Thread.sleep(2000);
	    }

	    @And("^Select Ram Capacity 2GB$")
	    public void select_ram_capacity_2gb() throws Throwable {
	       driver.findElement(flip.Chk_ramCapacity).click();
	       Thread.sleep(2000);
	    }

	    @And("^Clear Brand Filter at the top by clicking the x Button$")
	    public void clear_brand_filter_at_the_top_by_clicking_the_x_button() throws Throwable {
	       driver.findElement(flip.Filter_Close).click();
	       Thread.sleep(1000);
	       driver.findElement(flip.Filter_Close).click();
	       Thread.sleep(2000);
	    }

}
