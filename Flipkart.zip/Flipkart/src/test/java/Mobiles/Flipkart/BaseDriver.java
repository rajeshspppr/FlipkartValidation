package Mobiles.Flipkart;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseDriver {
	
	public static WebDriver driver;

	
	public static WebDriver getDriver() throws IOException, InterruptedException {
		
		
		
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
	 driver.get("https://www.flipkart.com");
		
		return driver;
		
		
	}
	

}
