package Mobiles.Flipkart;

import org.openqa.selenium.By;

public class flipkartXpath{
	
	public By Login_Close = By.xpath("//button[text()='✕']");
	
	public  By Fld_Search = By.xpath("//input[@type='text']");
	
	public  By Chk_ramCapacity = By.xpath("//div[text()='2 GB']");
	
	public  By Lnk_More = By.xpath("//span[contains(text(),'MORE')]");
	
	public  By Fld_SearchBrand = By.xpath("//input[@placeholder='Search Brand']");
	
	public  By Chk_Gionee = By.xpath("//div[text()='GIONEE']");
	
	public  By Btn_AplyFilters = By.xpath("//span[text()='Apply Filters']");
	
	public  By Lnk_FirstMobile = By.xpath("(//div[@style='flex-grow: 1; overflow: auto;']//div[contains(text(),'GIONEE')])[1]");
	
	public  By Txt_First2GB = By.xpath("(//div[@style='flex-grow: 1; overflow: auto;']//*[contains(text(),'2 GB RAM')])[1]");
	
	public  By Filter_Close = By.xpath("//div[text()='✕']");
	

}
